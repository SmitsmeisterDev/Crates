package nl.smitsmeister.mtcrates.commands;

import org.bukkit.command.*;
import nl.smitsmeister.mtcrates.*;
import nl.smitsmeister.mtcrates.objects.enums.*;
import nl.smitsmeister.mtcrates.objects.*;
import org.bukkit.*;
import java.util.*;

public class RMKCrates implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command cmd, final String s, final String[] args) {
        final CommandSender p = commandSender;
        if (!p.hasPermission("mtcrates.admin")) {
            p.sendMessage(" �cJe mist de permission mtcrates.admin");
            return true;
        }
        if (args.length == 0) {
            p.sendMessage("�7�m---------------------------------------------------");
            p.sendMessage(" �f�l �c�lMinetopia Crates �f- � Smitsmeister ");
            p.sendMessage("�7�m---------------------------------------------------");
            p.sendMessage("�c/mtcrates �fgive <player> <type> <amount> �8- �fGeef iemand een crate op zijn account");
            p.sendMessage("�c/mtcrates �fremove <player> <type> <amount> �8- �fHaal crates weg van iemand zijn account");
            p.sendMessage("�c/mtcrates �flist <player> �8- �fBekijk een speler zijn crate hoeveelheden.");
            p.sendMessage("�c/mtcrates �flist �8- �fZie de ingelade crates.");
            p.sendMessage("�c/mtcrates �freload �8- �fReload de configuratie zodat je nieuwe crates en rewards kan inladen.");
            p.sendMessage("�7�m---------------------------------------------------");
            p.sendMessage("�c/mtcrates �fgivexp <player> <xp> �8- �fGeef een speler XP");
            p.sendMessage("�c/mtcrates �ftakexp <player> <xp> �8- �fNeem een speler zijn XP af");
            p.sendMessage("�c/mtcrates �fgetxp <player> �8- �fZie een speler zijn XP");
            p.sendMessage("�c/mtxp �8- �fZie hoeveel XP je hebt");
            p.sendMessage("�7�m---------------------------------------------------");
            return true;
        }
        if (args.length == 1) {
            if (args[0].equalsIgnoreCase("reload")) {
                MTSCrates.getData().loadConfig();
                MTSCrates.getRewards().loadConfig();
                MTSCrates.getConfiguration().loadConfig();
                Reward.reload();
                p.sendMessage("�c�l �fDe config is �csuccesvol �fherladen.");
                return true;
            }
            p.sendMessage("�f�l cGeen correcte syntax van het commando.");
            return true;
        }
        else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("list")) {
                final OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                p.sendMessage("�c�l �fDe speler �c" + target.getName() + " �fheeft de volgende crate(s):");
                p.sendMessage(" ");
                for (final Crate c : MTSCrates.getCrates()) {
                    p.sendMessage("�c" + c.configKey + " �f- �7" + MTSCrates.getData().getConfig().getInt(target.getUniqueId().toString() + "." + c.configKey + ".amount") + " keer");
                }
                return true;
            }
            if (!args[0].equalsIgnoreCase("getxp")) {
                p.sendMessage("�f�l �cGeen correcte syntax van het commando.");
                return true;
            }
            final OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
            if (!MTSCrates.getData().getConfig().contains(target.getUniqueId().toString())) {
                p.sendMessage("�f�l �cDeze speler is nog nooit online geweest!");
                return true;
            }
            final XPHandler xpHandler = new XPHandler(target.getUniqueId());
            p.sendMessage("�c�l �fDe speler �c" + target.getName() + "�f heeft �c" + xpHandler.getXP() + "�f XP.");
            return true;
        }
        else if (args.length == 3) {
            if (args[0].equalsIgnoreCase("givexp")) {
                final String speler = args[1];
                final String xp = args[2];
                int xpInt;
                try {
                    xpInt = Integer.parseInt(xp);
                }
                catch (NumberFormatException e) {
                    p.sendMessage("�f�l �cDit is geen geldig getal!");
                    return true;
                }
                final OfflinePlayer target2 = Bukkit.getOfflinePlayer(speler);
                if (!MTSCrates.getData().getConfig().contains(target2.getUniqueId().toString())) {
                    p.sendMessage("�f�l �cDeze speler is nog nooit online geweest!");
                    return true;
                }
                final XPHandler handler = new XPHandler(target2.getUniqueId());
                handler.giveXP(xpInt);
                p.sendMessage("�c�l �fEr is �c" + xpInt + " �ftoegevoegd aan het account van �c" + target2.getName() + "�f.");
                return true;
            }
            else {
                if (!args[0].equalsIgnoreCase("takexp")) {
                    p.sendMessage("�f�l �cGeen correcte syntax van het commando.");
                    return true;
                }
                final String speler = args[1];
                final String xp = args[2];
                int xpInt;
                try {
                    xpInt = Integer.parseInt(xp);
                }
                catch (NumberFormatException e) {
                    p.sendMessage("�f�l �cDit is geen geldig getal!");
                    return true;
                }
                final OfflinePlayer target2 = Bukkit.getOfflinePlayer(speler);
                if (!MTSCrates.getData().getConfig().contains(target2.getUniqueId().toString())) {
                    p.sendMessage("�f�l �cDeze speler is nog nooit online geweest!");
                    return true;
                }
                final XPHandler handler = new XPHandler(target2.getUniqueId());
                handler.takeXP(xpInt);
                p.sendMessage("�c�l �fEr is �c" + xpInt + " �fverwijderd van het account van �c" + target2.getName() + "�f.");
                return true;
            }
        }
        else {
            if (args.length != 4) {
                return false;
            }
            if (args[0].equalsIgnoreCase("give")) {
                final OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                final String cratename = args[2].toLowerCase();
                Crate crate = null;
                for (final Crate c2 : MTSCrates.getCrates()) {
                    if (c2.configKey.toLowerCase().equals(cratename)) {
                        crate = c2;
                    }
                }
                if (crate == null) {
                    p.sendMessage("�f�l �cDeze crate bestaat niet!");
                    return true;
                }
                final String amountString = args[3];
                int amount;
                try {
                    amount = Integer.parseInt(amountString);
                }
                catch (NumberFormatException e2) {
                    p.sendMessage("�f�l �cDit is geen geldig getal!");
                    return true;
                }
                MTSCrates.getData().getConfig().set(target.getUniqueId().toString() + "." + crate.configKey + ".amount", (Object)(MTSCrates.getData().getConfig().getInt(target.getUniqueId().toString() + "." + crate.configKey + ".amount") + amount));
                MTSCrates.getData().saveConfig();
                p.sendMessage("�c�l �fJe hebt �c" + target.getName() + " �fsuccesvol �c" + amount + "x " + crate.configKey + " �ftoegevoegd aan zijn/haar account.");
                return true;
            }
            else {
                if (!args[0].equalsIgnoreCase("remove")) {
                    p.sendMessage("�f�l �cIncorrect usage of command");
                    return true;
                }
                final OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                final String cratename = args[2].toLowerCase();
                Crate crate = null;
                for (final Crate c2 : MTSCrates.getCrates()) {
                    if (c2.configKey.toLowerCase().equals(cratename)) {
                        crate = c2;
                    }
                }
                if (crate == null) {
                    p.sendMessage("�f�l �cDeze crate bestaat niet!");
                    return true;
                }
                final String amountString = args[3];
                int amount;
                try {
                    amount = Integer.parseInt(amountString);
                }
                catch (NumberFormatException e2) {
                    p.sendMessage("�f�l �cDit is geen geldig getal!");
                    return true;
                }
                MTSCrates.getData().getConfig().set(target.getUniqueId().toString() + "." + crate.configKey + ".amount", (Object)(MTSCrates.getData().getConfig().getInt(target.getUniqueId().toString() + "." + crate.configKey + ".amount") - amount));
                MTSCrates.getData().saveConfig();
                p.sendMessage("�c�l �fJe hebt �c" + target.getName() + " �fsuccesvol �c" + amount + "x " + crate.configKey + " �fverwijderd van zijn/haar account.");
                return true;
            }
        }
    }
}
