package nl.smitsmeister.mtcrates.commands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import nl.smitsmeister.mtcrates.objects.*;

public class XPCommand implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] strings) {
        if (!(commandSender instanceof Player)) {
            return true;
        }
        final Player p = (Player)commandSender;
        final XPHandler xpHandler = new XPHandler(p.getUniqueId());
        p.sendMessage("�c�l �fJe hebt �c" + xpHandler.getXP() + "�f XP op jouw account staan.");
        return true;
    }
}
