package nl.smitsmeister.mtcrates.events;

import org.bukkit.event.inventory.*;
import org.bukkit.entity.*;
import org.bukkit.block.*;
import org.bukkit.block.Block;

import nl.smitsmeister.mtcrates.*;
import nl.smitsmeister.mtcrates.objects.*;
import org.bukkit.scheduler.*;
import nl.smitsmeister.mtcrates.objects.enums.*;
import org.bukkit.craftbukkit.v1_12_R1.entity.*;
import com.gmail.filoghost.holographicdisplays.api.*;
import org.bukkit.command.*;
import org.bukkit.plugin.*;
import org.bukkit.event.*;
import org.bukkit.*;
import org.bukkit.Material;

import net.minecraft.server.v1_12_R1.*;
import java.util.*;

public class CratePurchaseHandler implements Listener
{
    private static List<Crate> cratesThatCantBeOpened;
    
    @EventHandler
    public void onInventory(final InventoryClickEvent event) {
        if (event.getInventory().getName().equalsIgnoreCase("Hoe wil je deze crate kopen?")) {
            event.setCancelled(true);
            final Player player = (Player)event.getWhoClicked();
            final Material material = (event.getCurrentItem() == null) ? null : event.getCurrentItem().getType();
            if (material == null || material.equals((Object)Material.AIR)) {
                return;
            }
            if (material.equals((Object)Material.BARRIER)) {
                player.closeInventory();
                return;
            }
            final Block block = CratePlaceEvent.lastCrate.get(player);
            Crate crate = null;
            for (final Crate c : MTSCrates.getCrates()) {
                if (c.color.material == block.getType()) {
                    crate = c;
                    break;
                }
            }
            final Reward reward = RewardOld.random(crate);
            if (reward == null) {
                player.sendMessage("�cDeze LootBox is op dit moment leeg, probeer het op een later moment nog eens!");
                return;
            }
            final Material crateType = crate.color.material;
            if (CratePurchaseHandler.cratesThatCantBeOpened.contains(crate)) {
                player.sendMessage(ChatColor.RED + "Er wordt op dit moment al een LootBox geopend!");
                player.closeInventory();
                return;
            }
            if (material.equals((Object)crateType)) {
                MTSCrates.getData().getConfig().set(player.getUniqueId().toString() + "." + crate.configKey + ".amount", (Object)(MTSCrates.getData().getConfig().getInt(player.getUniqueId().toString() + "." + crate.configKey + ".amount") - 1));
                MTSCrates.getData().saveConfig();
            }
            if (material.equals((Object)Material.EXP_BOTTLE)) {
                new XPHandler(player.getUniqueId()).takeXP(crate.cost);
            }
            if (material.equals((Object)Material.GOLD_NUGGET)) {
                final DailyCrate dailyCrate = new DailyCrate(player.getUniqueId());
                if (!dailyCrate.canClaim()) {
                    player.sendMessage("�eJe kan je daily kist openen over: �a" + TimeHelper.formatDuration(dailyCrate.getDiff()));
                    return;
                }
                Date dt = new Date();
                final Calendar c2 = Calendar.getInstance();
                c2.setTime(dt);
                c2.add(5, 1);
                dt = c2.getTime();
                MTSCrates.getData().getConfig().set(player.getUniqueId().toString() + ".gratis.nextClaimDate", (Object)dt);
                MTSCrates.getData().saveConfig();
            }
            player.closeInventory();
            CratePurchaseHandler.cratesThatCantBeOpened.add(crate);
            player.sendMessage(ChatColor.YELLOW + "Je bent nu je LootBox aan het openen!");
            this.createHelix(block.getLocation(), crate.particle);
            player.sendMessage(ChatColor.GREEN + "Je hebt je LootBox geopend!");
            final Crate finalCrate = crate;
            new BukkitRunnable() {
                public void run() {
                    final BlockPosition pos = new BlockPosition(block.getX(), block.getY(), block.getZ());
                    final PacketPlayOutBlockAction packet = new PacketPlayOutBlockAction(pos, (net.minecraft.server.v1_12_R1.Block)Blocks.CHEST, 1, 1);
                    for (final Player p : Bukkit.getOnlinePlayers()) {
                        ((CraftPlayer)p).getHandle().playerConnection.sendPacket((Packet)packet);
                    }
                    final Hologram hologram = MTSCrates.holograms.get(finalCrate);
                    hologram.clearLines();
                    hologram.appendTextLine(ChatColor.YELLOW + player.getName());
                    hologram.appendTextLine(ChatColor.GREEN + "Heeft " + reward.getRewardName() + " gewonnen!");
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.3f);
                    for (final String cmd : reward.getCommandToExecuteOnWin()) {
                        Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getConsoleSender(), cmd.replaceAll("%player%", player.getName()));
                    }
                    new BukkitRunnable() {
                        public void run() {
                            final BlockPosition pos = new BlockPosition(block.getX(), block.getY(), block.getZ());
                            final PacketPlayOutBlockAction packet = new PacketPlayOutBlockAction(pos, (net.minecraft.server.v1_12_R1.Block)Blocks.CHEST, 1, 0);
                            for (final Player p : Bukkit.getOnlinePlayers()) {
                                ((CraftPlayer)p).getHandle().playerConnection.sendPacket((Packet)packet);
                            }
                            final Hologram hologram = MTSCrates.holograms.get(finalCrate);
                            hologram.clearLines();
                            hologram.appendTextLine(finalCrate.title.replace("%cost%", String.valueOf(finalCrate.cost)));
                            hologram.appendTextLine(finalCrate.description.replace("%cost%", String.valueOf(finalCrate.cost)));
                            CratePurchaseHandler.cratesThatCantBeOpened.remove(finalCrate);
                        }
                    }.runTaskLater((Plugin)MTSCrates.getPlugin((Class)MTSCrates.class), 120L);
                }
            }.runTaskLater((Plugin)MTSCrates.getPlugin((Class)MTSCrates.class), 100L);
        }
    }
    
    private void createHelix(final Location loc, final EnumParticle enumParticle) {
        final double radius = 0.5;
        for (double y = 5.0; y > 0.0; y -= 0.05) {
            final double x = radius * Math.cos(y);
            final double z = radius * Math.sin(y);
            final PacketPlayOutWorldParticles packet1 = new PacketPlayOutWorldParticles(enumParticle, true, (float)(loc.getX() + x + 0.5), (float)(loc.getY() - y + 5.0), (float)(loc.getZ() + z + 0.5), 0.0f, 0.0f, 0.0f, 0.0f, 1, new int[0]);
            final PacketPlayOutWorldParticles packet2 = new PacketPlayOutWorldParticles(enumParticle, true, (float)(loc.getX() - x + 0.5), (float)(loc.getY() - y + 5.0), (float)(loc.getZ() - z + 0.5), 0.0f, 0.0f, 0.0f, 0.0f, 1, new int[0]);
            final Iterator<Player> iterator;
            Player online;
            final Packet packet3;
            final Packet packet4;
            this.setTimeout(() -> {
                Bukkit.getOnlinePlayers().iterator();
                while (iterator.hasNext()) {
                    online = iterator.next();
                    ((CraftPlayer)online).getHandle().playerConnection.sendPacket(packet3);
                    ((CraftPlayer)online).getHandle().playerConnection.sendPacket(packet4);
                }
                return;
            }, (int)(y * 750.0));
        }
    }
    
    private void setTimeout(final Runnable runnable, final int delay) {
        new Thread(() -> {
            try {
                Thread.sleep(delay);
                runnable.run();
            }
            catch (Exception e) {
                System.err.println(e);
            }
        }).start();
    }
    
    static {
        CratePurchaseHandler.cratesThatCantBeOpened = new ArrayList<Crate>();
    }
}
