package nl.smitsmeister.mtcrates.events;

import org.bukkit.entity.*;
import org.bukkit.block.*;
import nl.smitsmeister.mtcrates.gui.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import nl.smitsmeister.mtcrates.*;
import org.bukkit.*;
import nl.smitsmeister.mtcrates.objects.*;
import java.util.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.plugin.*;
import com.gmail.filoghost.holographicdisplays.api.*;
import org.bukkit.event.block.*;
import org.bukkit.event.inventory.*;

public class CratePlaceEvent implements Listener
{
    HashMap<Player, Block> lastBlock;
    public static HashMap<Player, Block> lastCrate;
    
    public CratePlaceEvent() {
        this.lastBlock = new HashMap<Player, Block>();
    }
    
    @EventHandler
    public void onBlockPlace(final BlockPlaceEvent e) {
        if (e.getBlock().getType().toString().contains("SHULKER_BOX")) {
            e.setCancelled(true);
            final SelectCrateGUI crateGUI = new SelectCrateGUI(e.getPlayer());
            crateGUI.prepare();
            crateGUI.open();
            this.lastBlock.put(e.getPlayer(), e.getBlock());
        }
    }
    
    @EventHandler
    public void onInteract(final PlayerInteractEvent e) {
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock().getType().toString().contains("SHULKER_BOX")) {
            Crate crate = null;
            for (final Crate c : MTSCrates.getCrates()) {
                if (c.color.material == e.getClickedBlock().getType()) {
                    crate = c;
                    break;
                }
            }
            if (crate != null) {
                e.setCancelled(true);
                CratePlaceEvent.lastCrate.put(e.getPlayer(), e.getClickedBlock());
                e.getPlayer().sendMessage("�eWaarmee wil je deze crate betalen?");
                final Inventory inv = Bukkit.createInventory((InventoryHolder)null, 27, "Hoe wil je deze crate kopen?");
                final ItemStack item = new ItemStack(Material.BARRIER, 1);
                final ItemMeta meta = item.getItemMeta();
                meta.setDisplayName("�cWeigeren");
                item.setItemMeta(meta);
                final XPHandler xpHandler = new XPHandler(e.getPlayer().getUniqueId());
                final int xp = xpHandler.getXP();
                int amountOfCratesXP = (int)Math.floor(xp / crate.cost);
                if (amountOfCratesXP > 64) {
                    amountOfCratesXP = 64;
                }
                final int amountOfCratesBought = MTSCrates.getData().getConfig().getInt(e.getPlayer().getUniqueId().toString() + "." + crate.configKey + ".amount");
                final ItemStack payXP = new ItemStack(Material.EXP_BOTTLE, amountOfCratesXP);
                final ItemMeta payXPMeta = payXP.getItemMeta();
                payXPMeta.setDisplayName("�bBetaal met XP");
                payXP.setItemMeta(payXPMeta);
                final ItemStack boughtCrate = new ItemStack(crate.color.material, amountOfCratesBought);
                final ItemMeta boughtCrateMeta = boughtCrate.getItemMeta();
                boughtCrateMeta.setDisplayName("�bBetaal met gekochte crate");
                boughtCrate.setItemMeta(boughtCrateMeta);
                final ItemStack claimFree = new ItemStack(Material.GOLD_NUGGET, 1);
                final ItemMeta claimFreeMeta = claimFree.getItemMeta();
                claimFreeMeta.setDisplayName("�aClaim gratis crate");
                claimFree.setItemMeta(claimFreeMeta);
                inv.setItem(11, item);
                if (amountOfCratesBought > 0) {
                    inv.setItem(13, boughtCrate);
                }
                if (crate.cost != -2) {
                    inv.setItem(15, payXP);
                }
                else {
                    inv.setItem(15, claimFree);
                }
                e.getPlayer().openInventory(inv);
            }
        }
    }
    
    @EventHandler
    public void onInvClick(final InventoryClickEvent e) {
        if (e.getInventory().getName().equals("�cSelecteer een crate")) {
            e.setCancelled(true);
            final Material material = e.getCurrentItem().getType();
            final Block b = this.lastBlock.get(e.getWhoClicked());
            b.setType(material);
            Crate crate = null;
            for (final Crate c : MTSCrates.getCrates()) {
                if (c.color.material == material) {
                    crate = c;
                    break;
                }
            }
            this.lastBlock.remove(e.getWhoClicked());
            e.getWhoClicked().sendMessage("�3Je hebt de crate " + crate.title + " �3aangemaakt!");
            final Hologram hologram = HologramsAPI.createHologram((Plugin)MTSCrates.getPlugin((Class)MTSCrates.class), b.getLocation().add(0.5, 2.3, 0.5));
            hologram.appendTextLine(crate.title.replace("%cost%", String.valueOf(crate.cost)));
            hologram.appendTextLine(crate.description.replace("%cost%", String.valueOf(crate.cost)));
            MTSCrates.getConfiguration().getConfig().set("crates." + crate.configKey + ".location", (Object)b.getLocation().add(0.5, 2.3, 0.5));
            MTSCrates.holograms.put(crate, hologram);
            MTSCrates.getConfiguration().saveConfig();
        }
    }
    
    @EventHandler
    public void onBlockBreak(final BlockBreakEvent e) {
        if (e.getBlock().getType().toString().contains("SHULKER_BOX")) {
            final Material material = e.getBlock().getType();
            Crate crate = null;
            for (final Crate c : MTSCrates.getCrates()) {
                if (c.color.material == material) {
                    crate = c;
                    break;
                }
            }
            MTSCrates.holograms.get(crate).delete();
        }
    }
    
    @EventHandler
    public void onInvClose(final InventoryCloseEvent e) {
        if (e.getInventory().getName().equals("�cSelecteer een crate")) {
            this.lastBlock.remove(e.getPlayer());
        }
    }
    
    static {
        CratePlaceEvent.lastCrate = new HashMap<Player, Block>();
    }
}
