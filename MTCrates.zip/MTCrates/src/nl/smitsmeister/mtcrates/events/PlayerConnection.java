package  nl.smitsmeister.mtcrates.events;

import org.bukkit.event.player.*;
import  nl.smitsmeister.mtcrates.*;
import org.bukkit.*;
import org.bukkit.scheduler.*;
import org.bukkit.entity.*;
import  nl.smitsmeister.mtcrates.objects.*;
import org.bukkit.plugin.*;
import java.util.*;
import org.bukkit.event.*;

public class PlayerConnection implements Listener
{
    @EventHandler
    public void onPlayerJoin(final PlayerJoinEvent e) {
        final Player p = e.getPlayer();
        for (final Crate c : MTSCrates.getCrates()) {
            if (MTSCrates.getData().getConfig().get(p.getUniqueId().toString() + "." + c.configKey) == null) {
                MTSCrates.getData().getConfig().set(p.getUniqueId().toString() + "." + c.configKey + ".amount", (Object)0);
                MTSCrates.getData().getConfig().set(p.getUniqueId().toString() + ".xp", (Object)0);
                if (c.configKey.equals("gratis")) {
                    final Date date = new Date();
                    MTSCrates.getData().getConfig().set(p.getUniqueId().toString() + "." + c.configKey + ".nextClaimDate", (Object)date);
                }
                MTSCrates.getData().saveConfig();
            }
        }
        Bukkit.getScheduler().runTaskLater((Plugin)MTSCrates.getPlugin((Class)MTSCrates.class), (BukkitRunnable)new BukkitRunnable() {
            public void run() {
                final DailyCrate dailyCrate = new DailyCrate(e.getPlayer().getUniqueId());
                if (dailyCrate.canClaim()) {
                    p.sendMessage("�aJe kunt je dagelijkse kist openen!");
                }
                else {
                    e.getPlayer().sendMessage("�eJe kan je daily kist openen over: �a" + TimeHelper.formatDuration(dailyCrate.getDiff()));
                }
            }
        }, 40L);
    }
}
