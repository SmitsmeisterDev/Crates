package nl.smitsmeister.mtcrates.gui;

import org.bukkit.entity.*;
import org.bukkit.*;
import nl.smitsmeister.mtcrates.*;
import nl.smitsmeister.mtcrates.objects.*;
import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.inventory.meta.*;

public class SelectCrateGUI
{
    private Player p;
    private Inventory inventory;
    
    public SelectCrateGUI(final Player p) {
        this.inventory = null;
        this.p = p;
    }
    
    public void prepare() {
        this.inventory = Bukkit.createInventory((InventoryHolder)null, 9, "�cSelecteer een crate");
        for (final Crate crate : MTSCrates.getCrates()) {
            final ItemStack item = new ItemStack(crate.color.material);
            final ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(crate.title);
            meta.setLore((List)Arrays.asList(crate.description));
            item.setItemMeta(meta);
            this.inventory.addItem(new ItemStack[] { item });
        }
    }
    
    public void open() {
        this.p.openInventory(this.inventory);
    }
}
