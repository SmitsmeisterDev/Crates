package nl.smitsmeister.mtcrates.objects;

import java.util.concurrent.*;

public class TimeHelper
{
    public static String formatDuration(final long duration) {
        final long hours = TimeUnit.MILLISECONDS.toHours(duration);
        final long minutes = TimeUnit.MILLISECONDS.toMinutes(duration) % 60L;
        final long seconds = TimeUnit.MILLISECONDS.toSeconds(duration) % 60L;
        if (String.valueOf(hours).startsWith("-") || String.valueOf(minutes).startsWith("-") || String.valueOf(seconds).startsWith("-")) {
            return "AVAILABLE_TO_OPEN";
        }
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
}
