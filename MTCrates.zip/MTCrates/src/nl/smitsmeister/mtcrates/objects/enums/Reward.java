package nl.smitsmeister.mtcrates.objects.enums;

import nl.smitsmeister.mtcrates.objects.*;
import nl.smitsmeister.mtcrates.*;
import org.bukkit.*;
import java.util.*;

public class Reward
{
    private static HashMap<Crate, List<Reward>> registeredRewards;
    private Crate crate;
    private String rewardName;
    private List<String> commandToExecuteOnWin;
    
    public Reward(final String rewardName, final Crate crate, final List<String> commandsToExecuteOnWin) {
        this.rewardName = rewardName;
        this.crate = crate;
        this.commandToExecuteOnWin = commandsToExecuteOnWin;
    }
    
    public static void loadAllCrates() {
        for (final String rewardKey : MTSCrates.getRewards().getConfig().getConfigurationSection("rewards").getKeys(false)) {
            System.out.println("Loading: " + rewardKey);
            final String mainkey = "rewards.";
            final String name = ".name";
            final String crate = ".crate";
            final String commands = ".commands";
            List<String> commandList = new ArrayList<String>();
            String rewardName = "";
            String crateName = "";
            if (MTSCrates.getRewards().getConfig().get(mainkey + rewardKey + commands) != null) {
                final boolean mayContinue = true;
                commandList = (List<String>)MTSCrates.getRewards().getConfig().getStringList(mainkey + rewardKey + commands);
                rewardName = MTSCrates.getRewards().getConfig().getString(mainkey + rewardKey + name);
                crateName = MTSCrates.getRewards().getConfig().getString(mainkey + rewardKey + crate);
                Crate c = null;
                for (final Crate c2 : MTSCrates.getCrates()) {
                    if (c2.configKey.toLowerCase().equals(crateName.toLowerCase())) {
                        c = c2;
                        break;
                    }
                }
                System.out.println("Crate: " + c);
                if (c == null) {
                    Bukkit.getLogger().warning("Crate naam is ongeldig bij reward -> (ID: " + rewardKey + ")");
                }
                else {
                    register(c, new Reward(rewardName, c, commandList));
                }
            }
        }
    }
    
    public static void reload() {
        Reward.registeredRewards = new HashMap<Crate, List<Reward>>();
        loadAllCrates();
    }
    
    public static void register(final Crate crate, final Reward reward) {
        if (Reward.registeredRewards.containsKey(crate)) {
            final List<Reward> rewardList = Reward.registeredRewards.get(crate);
            if (!rewardList.contains(reward)) {
                rewardList.add(reward);
            }
            Reward.registeredRewards.remove(crate);
            Reward.registeredRewards.put(crate, rewardList);
        }
        else {
            final List<Reward> rewardList = new ArrayList<Reward>();
            rewardList.add(reward);
            Reward.registeredRewards.put(crate, rewardList);
        }
    }
    
    public Crate getCrate() {
        return this.crate;
    }
    
    public String getRewardName() {
        return this.rewardName;
    }
    
    public List<String> getCommandToExecuteOnWin() {
        return this.commandToExecuteOnWin;
    }
    
    public static HashMap<Crate, List<Reward>> getRegisteredRewards() {
        return Reward.registeredRewards;
    }
    
    static {
        Reward.registeredRewards = new HashMap<Crate, List<Reward>>();
    }
}
