package nl.smitsmeister.mtcrates.objects.enums;

import nl.smitsmeister.mtcrates.objects.*;
import java.util.*;

public enum RewardOld
{
    LOOP((String)null, (String)null, false, (String)null);
    
    public String crate;
    public String rewardName;
    public boolean showImmediately;
    public String command;
    
    private RewardOld(final String rewardName, final String crate, final boolean showImmediately, final String command) {
        this.crate = crate;
        this.rewardName = rewardName;
        this.showImmediately = showImmediately;
        this.command = command;
    }
    
    public static Reward random(final Crate crate) {
        List<Reward> list = null;
        if (Reward.getRegisteredRewards().containsKey(crate)) {
            list = Reward.getRegisteredRewards().get(crate);
        }
        System.out.println(Reward.getRegisteredRewards());
        if (list == null) {
            return null;
        }
        if (list.size() == 0) {
            return null;
        }
        return list.get((int)(Math.random() * list.size()));
    }
}
