package nl.smitsmeister.mtcrates.objects;

import net.minecraft.server.v1_12_R1.*;

public class Crate
{
    public int cost;
    public String title;
    public String description;
    public CrateColor color;
    public EnumParticle particle;
    public boolean enabled;
    public boolean setup;
    public String configKey;
    
    public Crate(final int cost, final String title, final String description, final CrateColor color, final String particle) {
        this.enabled = true;
        this.setup = false;
        this.configKey = null;
        this.cost = cost;
        this.title = title.replaceAll("&", "�");
        this.description = description.replaceAll("&", "�");
        this.color = color;
        this.particle = EnumParticle.valueOf(particle);
    }
    
    public void setEnabled(final boolean enabled) {
        this.enabled = enabled;
    }
}
