package nl.smitsmeister.mtcrates.objects;

import java.util.*;
import org.bukkit.entity.*;
import nl.smitsmeister.mtcrates.*;

public class XPHandler
{
    private UUID uuid;
    
    public XPHandler(final Player p) {
        this.uuid = p.getUniqueId();
    }
    
    public XPHandler(final UUID p) {
        this.uuid = p;
    }
    
    public void giveXP(final int xp) {
        MTSCrates.getData().getConfig().set(this.uuid.toString() + ".xp", (Object)(this.getXP() + xp));
        MTSCrates.getData().saveConfig();
    }
    
    public void takeXP(final int xp) {
    	MTSCrates.getData().getConfig().set(this.uuid.toString() + ".xp", (Object)(this.getXP() - xp));
    	MTSCrates.getData().saveConfig();
    }
    
    public int getXP() {
        return MTSCrates.getData().getConfig().getInt(this.uuid.toString() + ".xp");
    }
}
