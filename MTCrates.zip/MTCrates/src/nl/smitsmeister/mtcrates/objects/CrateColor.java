package nl.smitsmeister.mtcrates.objects;

import org.bukkit.*;

public enum CrateColor
{
    GREEN(Material.GREEN_SHULKER_BOX), 
    BLUE(Material.BLUE_SHULKER_BOX), 
    PINK(Material.PINK_SHULKER_BOX), 
    PURPLE(Material.PURPLE_SHULKER_BOX), 
    YELLOW(Material.YELLOW_SHULKER_BOX), 
    ORANGE(Material.ORANGE_SHULKER_BOX), 
    SILVER(Material.SILVER_SHULKER_BOX), 
    RED(Material.RED_SHULKER_BOX);
    
    public Material material;
    
    private CrateColor(final Material material) {
        this.material = material;
    }
    
    @Override
    public String toString() {
        return super.toString();
    }
}
