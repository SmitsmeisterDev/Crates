package nl.smitsmeister.mtcrates.objects;

import java.util.*;
import nl.smitsmeister.mtcrates.*;

public class DailyCrate
{
    private UUID uuid;
    
    public DailyCrate(final UUID uuid) {
        this.uuid = uuid;
    }
    
    public boolean canClaim() {
        final Date now = new Date();
        final Date claimDate = (Date)MTSCrates.getData().getConfig().get(this.uuid.toString() + ".gratis.nextClaimDate");
        final long diff = claimDate.getTime() - now.getTime();
        return TimeHelper.formatDuration(diff).equalsIgnoreCase("AVAILABLE_TO_OPEN");
    }
    
    public long getDiff() {
        final Date now = new Date();
        final Date claimDate = (Date)MTSCrates.getData().getConfig().get(this.uuid.toString() + ".gratis.nextClaimDate");
        final long diff = claimDate.getTime() - now.getTime();
        return diff;
    }
}
