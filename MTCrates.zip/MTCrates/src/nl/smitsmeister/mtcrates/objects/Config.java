package nl.smitsmeister.mtcrates.objects;

import nl.smitsmeister.mtcrates.*;
import java.io.*;
import org.bukkit.configuration.file.*;
import org.bukkit.configuration.*;

public class Config
{
    private File file;
    private FileConfiguration config;
    private MTSCrates plugin;
    private String fileName;
    
    public Config(final String filename) {
        this.plugin = (MTSCrates)MTSCrates.getPlugin((Class)MTSCrates.class);
        this.fileName = filename;
    }
    
    public FileConfiguration getConfig() {
        return this.config;
    }
    
    public void saveConfig() {
        try {
            this.config.save(this.file);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void loadConfig() {
        this.file = new File(this.plugin.getDataFolder(), this.fileName);
        if (!this.file.exists()) {
            this.file.getParentFile().mkdirs();
            this.plugin.saveResource(this.fileName, false);
        }
        this.config = (FileConfiguration)new YamlConfiguration();
        try {
            this.config.load(this.file);
        }
        catch (IOException | InvalidConfigurationException ex2) {
            final Exception ex = null;
            final Exception e = ex;
            e.printStackTrace();
        }
    }
}
