package nl.smitsmeister.mtcrates;

import org.bukkit.plugin.java.*;
import nl.smitsmeister.mtcrates.objects.enums.*;
import nl.smitsmeister.mtcrates.events.PlayerConnection;
import org.bukkit.scheduler.*;
import org.bukkit.entity.*;
import org.bukkit.entity.Entity;
import org.bukkit.*;
import org.bukkit.metadata.*;
import org.bukkit.craftbukkit.v1_12_R1.entity.*;
import net.minecraft.server.v1_12_R1.*;
import org.bukkit.plugin.*;
import org.bukkit.command.*;
import nl.smitsmeister.mtcrates.commands.*;
import org.bukkit.event.*;
import nl.smitsmeister.mtcrates.events.*;
import nl.smitsmeister.mtcrates.objects.*;
import com.gmail.filoghost.holographicdisplays.api.*;
import java.util.*;

public final class MTSCrates extends JavaPlugin
{
    private static Config configuration;
    private static Config data;
    private static Config rewards;
    private static List<Crate> crates;
    public static HashMap<Crate, Hologram> holograms;
    
    public void onEnable() {
        (MTSCrates.configuration = new Config("config.yml")).loadConfig();
        (MTSCrates.data = new Config("data.yml")).loadConfig();
        (MTSCrates.rewards = new Config("rewards.yml")).loadConfig();
        this.loadCrates();
        Reward.loadAllCrates();
        this.loadCommands(this);
        this.loadListeners(this);
    }
    
    public void onDisable() {
        for (final Crate c : MTSCrates.crates) {
            MTSCrates.holograms.get(c).delete();
        }
    }
    
    public static Config getRewards() {
        return MTSCrates.rewards;
    }
    
    public static Config getConfiguration() {
        return MTSCrates.configuration;
    }
    
    public static Config getData() {
        return MTSCrates.data;
    }
    
    public void loadTasks() {
        Bukkit.getScheduler().runTaskTimer((Plugin)this, (BukkitRunnable)new BukkitRunnable() {
            public void run() {
                for (final Entity e : Bukkit.getWorld(MTSCrates.this.getConfig().getString("options.crate-world")).getEntities()) {
                    if (e instanceof ArmorStand && !e.getMetadata("originalLocation").isEmpty()) {
                        final Location location = (Location)e.getMetadata("originalLocation").get(0).value();
                        final EntityArmorStand entityArmorStand = ((CraftArmorStand)e).getHandle();
                        entityArmorStand.setLocation(location.getX(), location.getY(), location.getZ(), location.getPitch(), location.getYaw());
                    }
                }
            }
        }, 0L, 1L);
    }
    
    public void loadCommands(final MTSCrates plugin) {
        plugin.getCommand("mtcrates").setExecutor((CommandExecutor)new RMKCrates());
        plugin.getCommand("mtxp").setExecutor((CommandExecutor)new XPCommand());
    }
    
    public void loadListeners(final MTSCrates plugin) {
        Bukkit.getPluginManager().registerEvents((Listener)new CratePlaceEvent(), (Plugin)this);
        Bukkit.getPluginManager().registerEvents((Listener)new CratePurchaseHandler(), (Plugin)this);
        Bukkit.getPluginManager().registerEvents((Listener)new PlayerConnection(), (Plugin)this);
    }
    
    public static List<Crate> getCrates() {
        return MTSCrates.crates;
    }
    
    public void loadCrates() {
        for (final String crateName : MTSCrates.configuration.getConfig().getConfigurationSection("crates").getKeys(false)) {
            final Crate crate = new Crate(MTSCrates.configuration.getConfig().getInt("crates." + crateName + ".cost"), MTSCrates.configuration.getConfig().getString("crates." + crateName + ".title"), MTSCrates.configuration.getConfig().getString("crates." + crateName + ".description"), CrateColor.valueOf(MTSCrates.configuration.getConfig().getString("crates." + crateName + ".color")), MTSCrates.configuration.getConfig().getString("crates." + crateName + ".particles"));
            crate.configKey = crateName;
            boolean setup = false;
            if (MTSCrates.configuration.getConfig().get("crates." + crateName + ".location") != null) {
                setup = true;
            }
            if (setup) {
                final Location location = (Location)MTSCrates.configuration.getConfig().get("crates." + crateName + ".location");
                final Hologram hologram = HologramsAPI.createHologram((Plugin)getPlugin((Class)MTSCrates.class), location);
                hologram.appendTextLine(crate.title.replace("%cost%", String.valueOf(crate.cost)));
                hologram.appendTextLine(crate.description.replace("%cost%", String.valueOf(crate.cost)));
                MTSCrates.holograms.put(crate, hologram);
            }
            MTSCrates.crates.add(crate);
        }
    }
    
    static {
        MTSCrates.crates = new ArrayList<Crate>();
        MTSCrates.holograms = new HashMap<Crate, Hologram>();
    }
}
